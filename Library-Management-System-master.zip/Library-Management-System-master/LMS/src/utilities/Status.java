package utilities;

public enum Status {
	WARNING,ERROR,SUCCESS;

}

