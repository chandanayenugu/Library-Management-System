# Library-Management-System
Web based application to make the access of library easy and flexible for the users and librarians which involves different activities of the library, Searching and Borrowing books ,also keep track of the loans and book returns.
